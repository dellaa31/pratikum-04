<?php
// bikin variabel 
$nama = "Abdul Hamid";
$jurusan = "Sistem Informasi";
$semester = "2";
//menampilkan variabel
echo $nama;

?>