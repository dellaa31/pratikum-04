<?php
// bikin array mahasiswa 
$mahasiswa = ["adel","wahyu","anggun"];
// tampilan data pertama adel
echo $mahasiswa[0];
echo "<br>";
foreach ($mahasiswa as $mhs){
    echo $mhs . "<br>";
}
?>